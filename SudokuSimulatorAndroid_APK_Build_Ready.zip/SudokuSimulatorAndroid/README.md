# Sudoku Simulator Android project

This is the Android Studio source project for Sudoku Simulator. It is not itself an APK.

## Build an installable APK using GitHub Actions (no Android Studio needed)

1. Sign in to GitHub and create a **new private repository** (or use a repository you already own).
2. Upload the contents of this folder (`settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `app/`, and `.github/`) to the repository root. Do not upload the outer `SudokuSimulatorAndroid` folder as an extra nested level.
3. Open the repository's **Actions** tab. If prompted, enable Actions.
4. Select **Build Sudoku Simulator APK** on the left, then click **Run workflow**.
5. Wait for the workflow to finish successfully. Open the completed run, scroll to **Artifacts**, and download `SudokuSimulator-debug-apk`.
6. Extract the downloaded artifact ZIP. It contains `app-debug.apk`. Transfer it to your Android phone and tap it to install. If Android asks, allow installation from that source.

The workflow builds a debug APK. It is suitable for testing and sideloading; it is not a Play Store release build. The app still needs real-device testing before public distribution.

## Build locally in Android Studio

Open this folder as a project in Android Studio, allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

## Current prototype notes

- Offline app with no login.
- 9 levels, 9×9 Sudoku, Factory / Hospital / Market areas, hearts, math questions, retry/quit screens, and level unlock progression.
- Puzzle generation removes clues from a valid completed grid, but does not guarantee every puzzle has a unique solution.
- Validate puzzle logic, layout on multiple screen sizes, and gameplay before distributing publicly.
